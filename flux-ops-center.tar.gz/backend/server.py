from flask import Flask, jsonify, send_file
from flask_cors import CORS
import snowflake.connector
import os
import io
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from PIL import Image
from scipy.interpolate import RBFInterpolator

app = Flask(__name__)
CORS(app)

def get_snowflake_connection():
    """Create Snowflake connection using the CLI connection"""
    return snowflake.connector.connect(
        connection_name=os.getenv("SNOWFLAKE_CONNECTION_NAME") or "cpe_demo_CLI"
    )

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

@app.route('/api/assets', methods=['GET'])
def get_assets():
    try:
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        
        # Query all asset types from PRODUCTION schema with rich metadata
        assets = []
        
        # 1. Substations
        cursor.execute("""
            SELECT 
                SUBSTATION_ID as id,
                SUBSTATION_NAME as name,
                'substation' as type,
                LATITUDE,
                LONGITUDE,
                NULL as health_score,
                NULL as load_percent,
                NULL as usage_kwh,
                VOLTAGE_LEVEL as voltage,
                OPERATIONAL_STATUS as status,
                COMMISSIONED_DATE,
                CAPACITY_MVA
            FROM SI_DEMOS.PRODUCTION.SUBSTATIONS
            WHERE LATITUDE IS NOT NULL AND LONGITUDE IS NOT NULL
        """)
        for row in cursor.fetchall():
            assets.append({
                'ASSET_ID': row[0],
                'ASSET_NAME': row[1],
                'ASSET_TYPE': row[2],
                'LATITUDE': float(row[3]) if row[3] else None,
                'LONGITUDE': float(row[4]) if row[4] else None,
                'HEALTH_SCORE': float(row[5]) if row[5] is not None else None,
                'LOAD_PERCENT': float(row[6]) if row[6] is not None else None,
                'USAGE_KWH': float(row[7]) if row[7] is not None else None,
                'VOLTAGE': row[8],
                'STATUS': row[9],
                'COMMISSIONED_DATE': str(row[10]) if row[10] else None,
                'CAPACITY_MVA': float(row[11]) if row[11] else None
            })
        
        # 2. Transformers with hourly load data
        cursor.execute("""
            WITH latest_load AS (
                SELECT 
                    TRANSFORMER_ID,
                    AVG(LOAD_FACTOR_PCT) as avg_load_percent
                FROM SI_DEMOS.PRODUCTION.TRANSFORMER_HOURLY_LOAD
                WHERE LOAD_HOUR >= DATEADD(hour, -1, CURRENT_TIMESTAMP())
                GROUP BY TRANSFORMER_ID
            )
            SELECT 
                t.TRANSFORMER_ID as id,
                t.TRANSFORMER_ID as name,
                'transformer' as type,
                t.LATITUDE,
                t.LONGITUDE,
                NULL as health_score,
                COALESCE(l.avg_load_percent, UNIFORM(60, 95, RANDOM())) as load_percent,
                NULL as usage_kwh,
                '13.8kV' as voltage,
                'Operational' as status,
                t.LAST_MAINTENANCE_DATE as commissioned_date,
                t.RATED_KVA
            FROM SI_DEMOS.PRODUCTION.TRANSFORMER_METADATA t
            LEFT JOIN latest_load l ON t.TRANSFORMER_ID = l.TRANSFORMER_ID
            WHERE t.LATITUDE IS NOT NULL AND t.LONGITUDE IS NOT NULL
        """)
        for row in cursor.fetchall():
            assets.append({
                'ASSET_ID': row[0],
                'ASSET_NAME': row[1],
                'ASSET_TYPE': row[2],
                'LATITUDE': float(row[3]) if row[3] else None,
                'LONGITUDE': float(row[4]) if row[4] else None,
                'HEALTH_SCORE': float(row[5]) if row[5] is not None else None,
                'LOAD_PERCENT': float(row[6]) if row[6] is not None else None,
                'USAGE_KWH': float(row[7]) if row[7] is not None else None,
                'VOLTAGE': row[8],
                'STATUS': row[9],
                'COMMISSIONED_DATE': str(row[10]) if row[10] else None,
                'RATED_KVA': float(row[11]) if row[11] else None
            })
        
        # 3. Poles with health scores
        cursor.execute("""
            SELECT 
                POLE_ID as id,
                POLE_ID as name,
                'pole' as type,
                LATITUDE,
                LONGITUDE,
                HEALTH_SCORE,
                NULL as load_percent,
                NULL as usage_kwh,
                CIRCUIT_ID as voltage,
                CONDITION_STATUS as status,
                LAST_INSPECTION_DATE as commissioned_date,
                POLE_HEIGHT_FT
            FROM SI_DEMOS.PRODUCTION.GRID_POLES_INFRASTRUCTURE
            WHERE LATITUDE IS NOT NULL AND LONGITUDE IS NOT NULL
        """)
        for row in cursor.fetchall():
            assets.append({
                'ASSET_ID': row[0],
                'ASSET_NAME': row[1],
                'ASSET_TYPE': row[2],
                'LATITUDE': float(row[3]) if row[3] else None,
                'LONGITUDE': float(row[4]) if row[4] else None,
                'HEALTH_SCORE': float(row[5]) if row[5] is not None else None,
                'LOAD_PERCENT': float(row[6]) if row[6] is not None else None,
                'USAGE_KWH': float(row[7]) if row[7] is not None else None,
                'VOLTAGE': row[8],
                'STATUS': row[9],
                'COMMISSIONED_DATE': str(row[10]) if row[10] else None,
                'POLE_HEIGHT_FT': float(row[11]) if row[11] else None
            })
        
        # 4. Meters with spatial sampling (all data, sampled by grid cell)
        cursor.execute("""
            WITH recent_usage AS (
                SELECT 
                    METER_ID,
                    AVG(USAGE_KWH) as avg_usage_kwh
                FROM SI_DEMOS.PRODUCTION.AMI_INTERVAL_READINGS
                WHERE TIMESTAMP >= DATEADD(hour, -24, CURRENT_TIMESTAMP())
                GROUP BY METER_ID
            ),
            meters_gridded AS (
                SELECT 
                    m.METER_ID as id,
                    m.METER_ID as name,
                    'meter' as type,
                    m.METER_LATITUDE as latitude,
                    m.METER_LONGITUDE as longitude,
                    NULL as health_score,
                    NULL as load_percent,
                    COALESCE(u.avg_usage_kwh, UNIFORM(5, 50, RANDOM())) as usage_kwh,
                    m.CIRCUIT_ID as voltage,
                    'Operational' as status,
                    m.COMMISSIONED_DATE as commissioned_date,
                    m.CUSTOMER_SEGMENT_ID,
                    ROUND(m.METER_LATITUDE / 0.01) * 0.01 as grid_lat,
                    ROUND(m.METER_LONGITUDE / 0.01) * 0.01 as grid_lon,
                    ROW_NUMBER() OVER (
                        PARTITION BY ROUND(m.METER_LATITUDE / 0.01), ROUND(m.METER_LONGITUDE / 0.01)
                        ORDER BY COALESCE(u.avg_usage_kwh, UNIFORM(5, 50, RANDOM())) DESC
                    ) as rn
                FROM SI_DEMOS.PRODUCTION.METER_INFRASTRUCTURE m
                LEFT JOIN recent_usage u ON m.METER_ID = u.METER_ID
                WHERE m.METER_LATITUDE IS NOT NULL AND m.METER_LONGITUDE IS NOT NULL
            )
            SELECT 
                id, name, type, latitude, longitude, health_score, load_percent,
                usage_kwh, voltage, status, commissioned_date, CUSTOMER_SEGMENT_ID
            FROM meters_gridded
            WHERE rn <= 10
        """)
        for row in cursor.fetchall():
            assets.append({
                'ASSET_ID': row[0],
                'ASSET_NAME': row[1],
                'ASSET_TYPE': row[2],
                'LATITUDE': float(row[3]) if row[3] else None,
                'LONGITUDE': float(row[4]) if row[4] else None,
                'HEALTH_SCORE': float(row[5]) if row[5] is not None else None,
                'LOAD_PERCENT': float(row[6]) if row[6] is not None else None,
                'USAGE_KWH': float(row[7]) if row[7] is not None else None,
                'VOLTAGE': row[8],
                'STATUS': row[9],
                'COMMISSIONED_DATE': str(row[10]) if row[10] else None,
                'CUSTOMER_SEGMENT': row[11]
            })
        
        cursor.close()
        conn.close()
        
        print(f"Fetched {len(assets)} assets from SI_DEMOS.PRODUCTION: {sum(1 for a in assets if a['ASSET_TYPE'] == 'substation')} substations, {sum(1 for a in assets if a['ASSET_TYPE'] == 'transformer')} transformers, {sum(1 for a in assets if a['ASSET_TYPE'] == 'pole')} poles, {sum(1 for a in assets if a['ASSET_TYPE'] == 'meter')} meters")
        return jsonify(assets)
    
    except Exception as e:
        print(f"Error fetching assets: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/topology', methods=['GET'])
def get_topology():
    try:
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        
        # Build topology from PRODUCTION schema
        topology = []
        
        # Meter → Pole connections (uses SAME sampling as asset endpoint)
        cursor.execute("""
            WITH recent_usage AS (
                SELECT 
                    METER_ID,
                    AVG(USAGE_KWH) as avg_usage_kwh
                FROM SI_DEMOS.PRODUCTION.AMI_INTERVAL_READINGS
                WHERE TIMESTAMP >= DATEADD(hour, -24, CURRENT_TIMESTAMP())
                GROUP BY METER_ID
            ),
            sampled_meters AS (
                SELECT 
                    m.METER_ID,
                    m.POLE_ID,
                    m.METER_LATITUDE,
                    m.METER_LONGITUDE,
                    ROW_NUMBER() OVER (
                        PARTITION BY ROUND(m.METER_LATITUDE / 0.01), ROUND(m.METER_LONGITUDE / 0.01)
                        ORDER BY COALESCE(u.avg_usage_kwh, UNIFORM(5, 50, RANDOM())) DESC
                    ) as rn
                FROM SI_DEMOS.PRODUCTION.METER_INFRASTRUCTURE m
                LEFT JOIN recent_usage u ON m.METER_ID = u.METER_ID
                WHERE m.METER_LATITUDE IS NOT NULL 
                  AND m.METER_LONGITUDE IS NOT NULL
            )
            SELECT DISTINCT
                sm.METER_ID as from_id,
                sm.POLE_ID as to_id,
                sm.METER_LATITUDE as from_lat,
                sm.METER_LONGITUDE as from_lon,
                p.LATITUDE as to_lat,
                p.LONGITUDE as to_lon
            FROM sampled_meters sm
            JOIN SI_DEMOS.PRODUCTION.GRID_POLES_INFRASTRUCTURE p 
                ON sm.POLE_ID = p.POLE_ID
            WHERE sm.rn <= 10
              AND sm.POLE_ID IS NOT NULL
              AND p.LATITUDE IS NOT NULL
              AND p.LONGITUDE IS NOT NULL
        """)
        for row in cursor.fetchall():
            if row[0] and row[1]:
                topology.append({
                    'FROM_ASSET_ID': row[0],
                    'TO_ASSET_ID': row[1],
                    'FROM_LAT': float(row[2]) if row[2] else None,
                    'FROM_LON': float(row[3]) if row[3] else None,
                    'TO_LAT': float(row[4]) if row[4] else None,
                    'TO_LON': float(row[5]) if row[5] else None
                })
        
        # Pole → Transformer connections (all poles with transformers)
        cursor.execute("""
            SELECT DISTINCT
                p.POLE_ID as from_id,
                p.TRANSFORMER_ID as to_id,
                p.LATITUDE as from_lat,
                p.LONGITUDE as from_lon,
                t.LATITUDE as to_lat,
                t.LONGITUDE as to_lon
            FROM SI_DEMOS.PRODUCTION.GRID_POLES_INFRASTRUCTURE p
            JOIN SI_DEMOS.PRODUCTION.TRANSFORMER_METADATA t 
                ON p.TRANSFORMER_ID = t.TRANSFORMER_ID
            WHERE p.TRANSFORMER_ID IS NOT NULL
              AND p.LATITUDE IS NOT NULL
              AND p.LONGITUDE IS NOT NULL
              AND t.LATITUDE IS NOT NULL
              AND t.LONGITUDE IS NOT NULL
        """)
        for row in cursor.fetchall():
            if row[0] and row[1]:
                topology.append({
                    'FROM_ASSET_ID': row[0],
                    'TO_ASSET_ID': row[1],
                    'FROM_LAT': float(row[2]) if row[2] else None,
                    'FROM_LON': float(row[3]) if row[3] else None,
                    'TO_LAT': float(row[4]) if row[4] else None,
                    'TO_LON': float(row[5]) if row[5] else None
                })
        
        # Transformer → Substation connections (all transformers)
        cursor.execute("""
            SELECT DISTINCT
                t.TRANSFORMER_ID as from_id,
                t.SUBSTATION_ID as to_id,
                t.LATITUDE as from_lat,
                t.LONGITUDE as from_lon,
                s.LATITUDE as to_lat,
                s.LONGITUDE as to_lon
            FROM SI_DEMOS.PRODUCTION.TRANSFORMER_METADATA t
            JOIN SI_DEMOS.PRODUCTION.SUBSTATIONS s 
                ON t.SUBSTATION_ID = s.SUBSTATION_ID
            WHERE t.SUBSTATION_ID IS NOT NULL
              AND t.LATITUDE IS NOT NULL
              AND t.LONGITUDE IS NOT NULL
              AND s.LATITUDE IS NOT NULL
              AND s.LONGITUDE IS NOT NULL
        """)
        for row in cursor.fetchall():
            if row[0] and row[1]:
                topology.append({
                    'FROM_ASSET_ID': row[0],
                    'TO_ASSET_ID': row[1],
                    'FROM_LAT': float(row[2]) if row[2] else None,
                    'FROM_LON': float(row[3]) if row[3] else None,
                    'TO_LAT': float(row[4]) if row[4] else None,
                    'TO_LON': float(row[5]) if row[5] else None
                })
        
        cursor.close()
        conn.close()
        
        print(f"Fetched {len(topology)} topology connections from SI_DEMOS.PRODUCTION")
        return jsonify(topology)
    
    except Exception as e:
        print(f"Error fetching topology: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/kpis', methods=['GET'])
def get_kpis():
    try:
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT * FROM SI_DEMOS.APPLICATIONS.FLUX_OPS_CENTER_KPIS
        """
        
        cursor.execute(query)
        row = cursor.fetchone()
        
        if row:
            kpis = {
                'TOTAL_CUSTOMERS': row[0],
                'ACTIVE_OUTAGES': row[1],
                'TOTAL_LOAD_MW': float(row[2]) if row[2] else 0,
                'CREWS_ACTIVE': row[3],
                'AVG_RESTORATION_MINUTES': float(row[4]) if row[4] else 0
            }
        else:
            kpis = {}
        
        cursor.close()
        conn.close()
        
        return jsonify(kpis)
    
    except Exception as e:
        print(f"Error fetching KPIs: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/weather', methods=['GET'])
def get_weather():
    try:
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        
        # Get ALL hourly weather data for timeline scrubbing (July-August 2025)
        cursor.execute("""
            SELECT 
                TIMESTAMP_UTC,
                TEMP_F,
                HUMIDITY_PCT
            FROM SI_DEMOS.PRODUCTION.HOUSTON_WEATHER_HOURLY
            ORDER BY TIMESTAMP_UTC ASC
        """)
        
        weather = []
        for row in cursor.fetchall():
            weather.append({
                'TIMESTAMP': str(row[0]),
                'TEMP_F': float(row[1]) if row[1] else None,
                'HUMIDITY_PCT': float(row[2]) if row[2] else None
            })
        
        cursor.close()
        conn.close()
        
        print(f"Fetched {len(weather)} weather records from {weather[0]['TIMESTAMP']} to {weather[-1]['TIMESTAMP']}")
        return jsonify(weather)
    
    except Exception as e:
        print(f"Error fetching weather: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/weather/image', methods=['GET'])
def get_weather_image():
    """
    FLUX WEATHER INTELLIGENCE - Generate broadcast-quality weather gradient image
    
    Returns a smooth radial gradient PNG overlaying Houston metro area.
    Uses proper interpolation (RBF) for Weather Channel/NOAA style visualization.
    
    Query params:
    - temp_f: Temperature in Fahrenheit (default: 75)
    - width: Image width in pixels (default: 800)
    - height: Image height in pixels (default: 800)
    """
    try:
        from flask import request
        from scipy.interpolate import Rbf
        
        temp_f = float(request.args.get('temp_f', 75))
        width = int(request.args.get('width', 800))
        height = int(request.args.get('height', 800))
        
        # Weather Channel / NOAA style color mapping
        def get_weather_color_rgb(temp):
            if temp < 60: return np.array([65, 182, 196])
            if temp < 70: return np.array([127, 205, 187])
            if temp < 75: return np.array([199, 233, 180])
            if temp < 80: return np.array([255, 255, 178])
            if temp < 85: return np.array([254, 217, 118])
            if temp < 90: return np.array([253, 165, 70])
            if temp < 95: return np.array([250, 100, 50])
            return np.array([220, 40, 40])
        
        # Create spatial temperature variation
        np.random.seed(int(temp_f * 10) % 1000)
        num_centers = np.random.randint(8, 13)
        
        center_x = np.random.uniform(0.1, 0.9, num_centers)
        center_y = np.random.uniform(0.1, 0.9, num_centers)
        center_temps = temp_f + np.random.uniform(-8, 8, num_centers)
        
        # Create meshgrid for interpolation
        x = np.linspace(0, 1, width)
        y = np.linspace(0, 1, height)
        X, Y = np.meshgrid(x, y)
        
        # RBF interpolation for smooth temperature field
        rbf = Rbf(center_x, center_y, center_temps, function='gaussian', smooth=0.3)
        temp_field = rbf(X, Y)
        
        # Create RGBA image with spatially-varying colors
        img_array = np.zeros((height, width, 4), dtype=np.uint8)
        
        for i in range(height):
            for j in range(width):
                temp_at_pixel = temp_field[i, j]
                color = get_weather_color_rgb(temp_at_pixel)
                img_array[i, j, 0] = color[0]
                img_array[i, j, 1] = color[1]
                img_array[i, j, 2] = color[2]
                img_array[i, j, 3] = 180
        
        img = Image.fromarray(img_array, 'RGBA')
        
        buf = io.BytesIO()
        img.save(buf, format='PNG', optimize=True)
        buf.seek(0)
        
        return send_file(buf, mimetype='image/png', as_attachment=False)
    
    except Exception as e:
        print(f"Error generating weather image: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("Starting Flask backend server on port 3001...")
    print("Connecting to Snowflake using connection: cpe_demo_CLI")
    print("Data source: SI_DEMOS.PRODUCTION schema")
    app.run(host='0.0.0.0', port=3001, debug=True)
