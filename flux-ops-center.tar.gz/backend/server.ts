import express from 'express';
import snowflake from 'snowflake-sdk';
import cors from 'cors';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Snowflake connection configuration using JWT authentication
const privateKeyPath = process.env.SNOWFLAKE_PRIVATE_KEY_PATH || 
  path.join(process.env.HOME || '', '.snowflake', 'rsa_key.p8');

let snowflakeConfig: any;

if (fs.existsSync(privateKeyPath)) {
  const privateKeyData = fs.readFileSync(privateKeyPath, 'utf8');
  snowflakeConfig = {
    account: process.env.SNOWFLAKE_ACCOUNT || 'GZB42423',
    username: process.env.SNOWFLAKE_USERNAME || 'CORTEX_CLI_CPE_SVC',
    authenticator: 'SNOWFLAKE_JWT',
    privateKey: privateKeyData,
    warehouse: process.env.SNOWFLAKE_WAREHOUSE || 'SI_DEMO_WH',
    database: process.env.SNOWFLAKE_DATABASE || 'SI_DEMOS',
    schema: process.env.SNOWFLAKE_SCHEMA || 'APPLICATIONS',
    role: process.env.SNOWFLAKE_ROLE || 'ACCOUNTADMIN'
  };
} else {
  // Fallback to username/password
  snowflakeConfig = {
    account: process.env.SNOWFLAKE_ACCOUNT || 'GZB42423',
    username: process.env.SNOWFLAKE_USERNAME,
    password: process.env.SNOWFLAKE_PASSWORD,
    authenticator: process.env.SNOWFLAKE_AUTHENTICATOR || 'SNOWFLAKE',
    warehouse: process.env.SNOWFLAKE_WAREHOUSE || 'SI_DEMO_WH',
    database: process.env.SNOWFLAKE_DATABASE || 'SI_DEMOS',
    schema: process.env.SNOWFLAKE_SCHEMA || 'APPLICATIONS',
    role: process.env.SNOWFLAKE_ROLE || 'ACCOUNTADMIN'
  };
}

let connection: snowflake.Connection | null = null;

// Initialize Snowflake connection
async function initSnowflakeConnection(): Promise<void> {
  return new Promise((resolve, reject) => {
    connection = snowflake.createConnection(snowflakeConfig);
    connection.connect((err, conn) => {
      if (err) {
        console.error('Failed to connect to Snowflake:', err);
        reject(err);
      } else {
        console.log('Successfully connected to Snowflake');
        resolve();
      }
    });
  });
}

// Execute Snowflake query
async function executeQuery<T = any>(sqlText: string): Promise<T[]> {
  if (!connection) {
    throw new Error('Not connected to Snowflake');
  }

  return new Promise((resolve, reject) => {
    connection!.execute({
      sqlText,
      complete: (err, stmt, rows) => {
        if (err) {
          console.error('Failed to execute query:', err);
          reject(err);
        } else {
          resolve(rows as T[]);
        }
      }
    });
  });
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Get all assets from SI_DEMOS.APPLICATIONS.FLUX_OPS_CENTER_ASSETS
app.get('/api/assets', async (req, res) => {
  try {
    // Fetch all infrastructure assets (substations, transformers, poles)
    // and downsample meters using spatial gridding to avoid overwhelming the client
    const query = `
      WITH infrastructure AS (
        SELECT 
          ASSET_ID,
          ASSET_NAME,
          ASSET_TYPE,
          LATITUDE,
          LONGITUDE,
          HEALTH_SCORE,
          LOAD_PERCENT,
          USAGE_KWH
        FROM SI_DEMOS.APPLICATIONS.FLUX_OPS_CENTER_ASSETS
        WHERE LATITUDE IS NOT NULL 
          AND LONGITUDE IS NOT NULL
          AND ASSET_TYPE IN ('Substation', 'Transformer', 'Pole')
      ),
      meters_sampled AS (
        SELECT 
          ASSET_ID,
          ASSET_NAME,
          ASSET_TYPE,
          LATITUDE,
          LONGITUDE,
          HEALTH_SCORE,
          LOAD_PERCENT,
          USAGE_KWH,
          -- Create spatial grid cells (0.01 degree = ~1km)
          ROUND(LATITUDE / 0.01) * 0.01 as grid_lat,
          ROUND(LONGITUDE / 0.01) * 0.01 as grid_lon,
          ROW_NUMBER() OVER (
            PARTITION BY ROUND(LATITUDE / 0.01), ROUND(LONGITUDE / 0.01)
            ORDER BY USAGE_KWH DESC NULLS LAST, LOAD_PERCENT DESC NULLS LAST
          ) as rn
        FROM SI_DEMOS.APPLICATIONS.FLUX_OPS_CENTER_ASSETS
        WHERE LATITUDE IS NOT NULL 
          AND LONGITUDE IS NOT NULL
          AND ASSET_TYPE = 'Meter'
      )
      SELECT 
        ASSET_ID,
        ASSET_NAME,
        ASSET_TYPE,
        LATITUDE,
        LONGITUDE,
        HEALTH_SCORE,
        LOAD_PERCENT,
        USAGE_KWH
      FROM infrastructure
      UNION ALL
      SELECT 
        ASSET_ID,
        ASSET_NAME,
        ASSET_TYPE,
        LATITUDE,
        LONGITUDE,
        HEALTH_SCORE,
        LOAD_PERCENT,
        USAGE_KWH
      FROM meters_sampled
      WHERE rn <= 5  -- Keep top 5 meters per grid cell
    `;

    const results = await executeQuery(query);
    console.log(`Fetched ${results.length} assets from Snowflake (with intelligent meter sampling)`);
    res.json(results);
  } catch (error) {
    console.error('Error fetching assets:', error);
    res.status(500).json({ error: 'Failed to fetch assets' });
  }
});

// Get KPIs from unified view
app.get('/api/kpis', async (req, res) => {
  try {
    const query = `
      SELECT * FROM SI_DEMOS.APPLICATIONS.FLUX_OPS_CENTER_KPIS
    `;

    const results = await executeQuery(query);
    res.json(results[0] || {});
  } catch (error) {
    console.error('Error fetching KPIs:', error);
    res.status(500).json({ error: 'Failed to fetch KPIs' });
  }
});

// Get topology connections between infrastructure
app.get('/api/topology', async (req, res) => {
  try {
    const query = `
      SELECT 
        FROM_ASSET_ID,
        TO_ASSET_ID,
        FROM_LAT,
        FROM_LON,
        TO_LAT,
        TO_LON
      FROM SI_DEMOS.APPLICATIONS.FLUX_OPS_CENTER_TOPOLOGY
      LIMIT 10000
    `;

    const results = await executeQuery(query);
    console.log(`Fetched ${results.length} topology connections from Snowflake`);
    res.json(results);
  } catch (error) {
    console.error('Error fetching topology:', error);
    res.status(500).json({ error: 'Failed to fetch topology' });
  }
});

// Get active outages from SI_DEMOS.PRODUCTION
app.get('/api/outages', async (req, res) => {
  try {
    const query = `
      SELECT 
        OUTAGE_ID as outage_id,
        29.7604 as latitude,
        -95.3698 as longitude,
        AFFECTED_CUSTOMERS_COUNT as customers_affected,
        OUTAGE_START_TIMESTAMP as start_time,
        EXPECTED_RESTORATION_TIME as estimated_restoration,
        RESTORATION_STATUS as status
      FROM SI_DEMOS.PRODUCTION.OUTAGE_RESTORATION_TRACKER
      WHERE RESTORATION_STATUS = 'IN_PROGRESS'
      ORDER BY AFFECTED_CUSTOMERS_COUNT DESC
      LIMIT 100
    `;

    const results = await executeQuery(query);
    res.json(results);
  } catch (error) {
    console.error('Error fetching outages:', error);
    res.status(500).json({ error: 'Failed to fetch outages' });
  }
});

// Initialize and start server
(async () => {
  try {
    await initSnowflakeConnection();
    app.listen(PORT, () => {
      console.log(`Backend API server running on port ${PORT}`);
      console.log(`Health check: http://localhost:${PORT}/health`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
})();
